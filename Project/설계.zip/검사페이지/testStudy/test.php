<html>

        <head>

                <meta http-equiv="Content-Type" content="text/html;charset=utf-8" >

        </head>

        <body>

                <?php

                echo $_REQUEST['nickname'].'님의 직업은 '.$_REQUEST['job'].'이군요!';

                ?>

        </body>

</html>