$('button.survay-btn').click(function(){//버튼을 클릭하면
    var error='';
    $('div.survays').each(function(){
        var survaysName=$(this).find('p.survaysName').text();//해당설문이름 가져오기
        var checkBtn=$(this).find('input[type="radio"]:checked');//체크한 것들
        if(!checkBtn.length){//체크하지 않았으면
            error+=survaysName+'선택하지 않은 문항이 있습니다. 다시 한번 확인 부탁드립니다.\n';//경고문저장
        }
    });
    if(error) alert(error);//경고문이 있으면 경고하기
});